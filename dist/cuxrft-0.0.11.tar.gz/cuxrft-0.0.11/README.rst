.. image:: https://raw.githubusercontent.com/timvgl/CuXRFT/main/cuxrft.png
   :width: 200
   
Documentation
=============
`Documentation of cuxrft at readthedocs <https://cuxrft.readthedocs.io/en/latest/>`_

